<script type="text/javascript" charset="utf-8">//
	$(document).ready(function() {
	
	
		$(document).on('change', '#page_type', function (e) {
			var open_type	=	$("#page_type").val();
			if(open_type=='yes'){
				$('.urldiv').hide();
			}
			if(open_type=='no'){
				$('.urldiv').show();
			}
			
		});
		
		
	});		
</script>	
<?php
	if($this->uri->segment(3)=='Add'){
		$btnlable="Insert";
	}
	else{
		$btnlable="Update";
	//	$new_date = date('m/d/Y', strtotime($result[0]['date']));
	}
?>

<h2>recipe  <?=$this->uri->segment(3)?></h2>
<div class="panel-body">
  <form role="form" action="<?php echo base_url();?>index.php/<?=$this->uri->segment(1)?>/insertrecord" id="form1" method="post" class="form-horizontal form-groups-bordered validate" enctype="multipart/form-data">
        <input type="hidden" name="mode" id="mode" value="<?=$this->uri->segment(3)?>" />
        <input type="hidden" name="eid" id="eid" 	 value="<?=$this->uri->segment(4)?>" />
    <div class="form-group">
      <label class="col-sm-3 control-label">Recipe Name</label>
      <div class="col-sm-7">
        	<input type="text" name="recipe_name" id="recipe_name" value="<?=$result[0]['recipe_name']?>" class="form-control" data-validate="required" data-message-required="Enter Contain" placeholder="Title" />
      </div>
    </div>
     <div class="form-group">
      <label class="col-sm-3 control-label">Url</label>
      <div class="col-sm-7">
          <input type="text" name="url" id="url" value="<?=$result[0]['url']?>" class="form-control" data-validate="required" data-message-required="Enter Contain" placeholder="Title" />
      </div>
    </div>

    <div class="form-group">
    <div class="col-sm-4">
      		<button type="submit" class="btn btn-success"><?=$btnlable?></button>
      		<a href="<?php echo base_url();?>index.php/<?=$this->uri->segment(1)?>" class="btn btn-danger">Reset</a>
      </div>
    </div>
  </form>
</div>


<style>
.page-body h2{
  margin: 40px 0px 10px 20px;
}

.panel-body{
  margin: 10px 20px 0px 30px;
}

</style>