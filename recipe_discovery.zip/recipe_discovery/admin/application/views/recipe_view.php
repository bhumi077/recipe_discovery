
<div class="row">
<input type="hidden" value="<?php echo base_url();?>index.php/<?=$this->uri->segment(1)?>/listing" id="url_list" />

<div class="col-sm-4 addnewbtn">
   <a class="btn btn-grey" href="<?=base_url();?>index.php/login/logout"> Log Out</a>

	<a class="btn btn-blue" href="<?php echo base_url();?>index.php/<?=$this->uri->segment(1)?>/addnew/Add" class="btn btn-grey">Add New</a>
</div> 
</div>
<h2 id="list_heading">recipe List</h2>           
  <table class="table table-bordered" id="example">
    <thead>
      <tr class='thefilter'>
            <th width="5%">No</th>
            <th width="15%">Recipe Name</th>
            <th width="15%">Url</th>
            <th width="15%">Status</th>
            <th width="20%">Operation</th>
      </tr>
    </thead>
    <tbody>
    </tbody>
    
  </table>
  <style>
#example_length{
display: none;
}
#example_filter{
  display: none;
}
.row{
  margin: 20px 0px -50px 0px;
}
#example_info{
  display: none;
}
.btn-grey{
  background-color: #ccc;
  margin: 0px -70px 70px 0px
}
.btn-blue{
  margin: 16px 34px 0px 0px;
}
#list_heading{
margin: -56px 10px 0px 10px;
}

</style>



