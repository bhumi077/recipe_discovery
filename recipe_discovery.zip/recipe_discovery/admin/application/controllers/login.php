<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class login extends CI_Controller {

	function __construct()
 	{
   		parent::__construct(); 
		$this->load->model('login_module','',TRUE);
   		$this->load->helper('form');// here we load form class
   		$this->load->helper('url');
   		$this->load->library('form_validation');
   		$this->load->helper('date');
   		$this->load->library('email');
 	}
	public function index()
	{
		if($this->session->userdata('logged_in'))
   		{
			header('Location: '.base_url().'index.php/dashboard');
			exit;
   		}
   		else
   		{
     		$this->load->view('login_view');
   		}
	}
	public function login_submit()
	{
		
		if($this->session->userdata('logged_in'))
	 	{
	 		header('Location: '.base_url());
			exit;
	    }
		
		$this->form_validation->set_rules('username', 'Username', 'required');
	 	$this->form_validation->set_rules('password', 'Password', 'required');
	 	
		if ($this->form_validation->run() == FALSE)
	 	{
		 	$data['error']='Invalid Username or password';
         	$this->load->view('login_view',$data);	
		}
		else{
			
			$username 	= 	$this->input->post('username');
		 	$password	=	$this->input->post('password');
     	 	$result 	= 	$this->login_module->loginsub($username, $password);
			
			
			if($result)
     	 	{ 
					
					
					$sess_array = array();
					foreach($result as $row)
            		{	
						$sess_array = array(
					 	'usercode' => $row->usercode,
					 	'first_name' => $row->first_name,
					 	'last_name' => $row->last_name,
					 	'email' => $row->email
             		);
				
					$this->session->set_userdata('logged_in', $sess_array);
					//$student_yearly 	= 	$this->login_module->get_current_year();		
					//$setting_array = array();
					
					
					header('Location: '.base_url().'index.php/recipe');
				}
			}
			else{
				
				$data['error']='Invalid Username or password';
         		$this->load->view('login_view',$data);	
			}
			
		}
	
	}
	
	function logout()
 	{
		$this->session->sess_destroy();
		header('Location: '.base_url().'index.php/login');
		exit;
    //redirect('vendor', 'refresh');
 }

}


