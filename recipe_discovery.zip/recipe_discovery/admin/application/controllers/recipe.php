<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class recipe extends CI_Controller {

	function __construct()
 	{
   		parent::__construct(); 
		$this->load->model('recipe_model','',TRUE);
   		$this->load->helper('form');
   		$this->load->helper('url');
		//$this->load->helper('date');
		$this->load->library('upload');
		$this->load->library('image_lib');
		
		if(!$this->session->userdata('logged_in')){header('Location: '.base_url().'index.php/login');exit;}
		
 	}
	public function index()
	{
		
		$this->load->view('comman/topheader');
		
		$this->load->view('recipe_view',$data);
		
	}
	function listing(){
		
		$result=$this->recipe_model->getAll();
		
		//echo $this->db->last_query();
		echo '{ "aaData":[';
		$data = "";
		
		$rowno=0;
		for($i=0;$i<count($result);$i++)
		{	
			$rowno++;
            if($result[$i]['status']=='Active'){
                   $currentst='Active';
                   $nm='Inactive';
            }
            else{
                   $currentst='Inactive';
                   $nm='Active';
            }

			$p="";
			
			
			$p="<a href='".base_url()."index.php/recipe/addnew/Edit/".$result[$i]['recipe_code']."' class='btn btn-default btn-sm' rel='tooltip' title='Edit'><i class='entypo-pencil'></i></a>&nbsp;&nbsp;&nbsp;";
            $p.="<a href='index.php' class='btn btn-danger btn-sm delrcd' rel='tooltip' title='Delete' value='".base_url()."index.php/recipe/deleterecord/".$result[$i]['recipe_code']."'><i class='entypo-cancel'></i></a>";
			$sta="".$currentst."&nbsp;|&nbsp;<a href='#' class='statuschange' value='".base_url()."index.php/recipe/record_update/".$nm."/".$result[$i]['recipe_code']."'>".$nm."</a>";
			$rowcount=$i+1;	
			$data.='["'.$rowcount.'","'.$result[$i]['recipe_name'].'","'.$result[$i]['url'].'","'.$sta.'","'.$p.'"],';
		}
		echo substr($data,0,-1);
		echo "] }";	 	 	
	}
	
	function addnew(){
		
		
		
		if($this->uri->segment(3)=='Edit'){
			$data['result']=$this->recipe_model->get_record($this->uri->segment(4));
		}
		$this->load->view('comman/topheader');
		
		$this->load->view('recipe_add',$data);
	
	}
	function insertrecord(){
		
		if ($this->input->server('REQUEST_METHOD') === 'POST')
		{	
			$now = time();
			
			$data = array();
			$data['recipe_name']		=	$this->input->post('recipe_name');
			$data['url']		=	$this->input->post('url');
			
			
			if($this->input->post('mode')=="Add")
			{
			
				$country_code			=	$this->recipe_model->addItem($data,'recipe_master');
			}
			if($this->input->post('mode')=="Edit")
			{
				
				$this->recipe_model->update($data,'recipe_master','recipe_code',$this->input->post('eid'));	
			}
			
		}
		header('Location: '.base_url().'index.php/recipe');
		exit;
	}
	
	function record_update(){
		$data=array();
		$data['status']=$this->uri->segment(3);
		$this->recipe_model->update($data,'recipe_master','recipe_code',$this->uri->segment(4));	
		
	}
	function deleterecord(){
		$this->recipe_model->deletercd($this->uri->segment(3));
	}


}


