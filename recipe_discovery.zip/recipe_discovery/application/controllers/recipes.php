<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class recipes extends CI_Controller {

	function __construct()
 	{
   		parent::__construct(); 
		$this->load->model('recipes_model','',TRUE);
   		$this->load->helper('form');
   		$this->load->helper('url');
		$this->load->helper('date');
	
		
 	}
	public function index()
	{
		
		// /$data['result']=$this->recipes_model->get_contain();
		$data['recipe']=$this->recipes_model->get_recipe();
		$this->load->view('recipes_view',$data);
		
	}


	public function serch()
	{
		$output = '';
			$query = '';
			//$this->load->model('recipes_model');
			if($this->input->post('query'))
			{
				$query = $this->input->post('query');
			}
				$data = $this->recipes_model->serch_recipe($query);

				$output=' <div class="col-lg-12 top30">';
	  for($i=0;$i<count($recipe);$i++){
	    $output.='<div class="col-lg-3 paddingleftno">
	    			<h2 id="h2_head">'.$recipe[$i]['url'].'
	               <div id="video_div">
	              <iframe  id="video_frame"  src="'.$recipe[$i]['url'].'" frameborder="0" allowfullscreen></iframe></div>
	            	</h2>
	            	</div>';
	            	}        
	     $output.='</div>';
	 	echo $output;

 	}

 
}


