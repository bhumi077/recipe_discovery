<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class serch extends CI_Controller {

  function __construct()
  {
      parent::__construct(); 
    $this->load->model('serch_model','',TRUE);
      $this->load->helper('form');
      $this->load->helper('url');
    $this->load->helper('date');
  
    
  }
  public function ajaxsearch()
    {
      
       if(is_null($this->input->get('id')))
        {

        $this->load->view('serch_view');    
    
        
        }
        else
        {
        //$this->load->model('serch_model'); 
        
        $data['booktable']=$this->serch_model->serch($this->input->get('id')); 
        
        $this->load->view('output',$data);
        
        }
        
       
    }


  

 
}


