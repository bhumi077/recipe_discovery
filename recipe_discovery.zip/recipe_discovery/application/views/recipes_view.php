<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
  <script>
$(document).ready(function(){
var base=$('#base_url').val();
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"<?php echo base_url(); ?>recipes/serch",
   method:"POST",
   data:{query:query},
   success:function(data){
    $('#result').html(data);
   }
  })
 }

 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>
		<section id="content">
			
				<div class="row">
              <h2> Recipe </h2> 
              <div class="search-box">

              <span>Search</span>
             <input type="text" name="search_text" id="search_text" placeholder="Search by keyword" class="form-control" />
            </div>
        <div id="result"></div>
      </div>
                  
               <?php for($i=0;$i<count($recipe);$i++){ 
	  	?>                    	
                    <h2 id="h2_head">
                      <?=$recipe[$i]['recipe_name']?>
                    <div id="video_div">
                      <iframe  id="video_frame"  src="<?=$recipe[$i]['url']?>" frameborder="0" allowfullscreen></iframe>
                    </div>
                    </h2>
                
                <?php }?>

				
			
		</section>

<style>
#content{
  margin: 30px;

}
#h2_head{
float: left;
padding-left: 20px;
margin-top: 0px;
}
#video_frame{
  margin-top:20px;
  height: 200px;
width: 270px;
}
#search_tex{
  height: 50px;
  width: 500px;
}
</style>