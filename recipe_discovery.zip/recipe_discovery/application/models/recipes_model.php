<?php
Class recipes_model extends CI_Model
{
 	
	
	
	function get_recipe(){
		$this -> db -> select('*');
   		$this -> db -> from('recipe_master');
		$this -> db -> where('status','Active');
		$query = $this -> db -> get();
    	$the_content = $query->result_array();
    	return $the_content;
	}	



	function serch_recipe($query){
		$this -> db -> select('*');
		$this -> db -> from('recipe_master');
		$this -> db -> where('status','Active');
		if($query != '')
  {
  	$this->db->like('recipe_name', $query);

	}
	$this->db->order_by('recipe_code', 'DESC');
  return $this->db->get();
	}	
}
?>
